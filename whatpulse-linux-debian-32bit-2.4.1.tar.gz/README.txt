WhatPulse requires some packages and permissions to work properly.

Please read http://whatpulse.org/kb/content/7/15/en/linux-installation.html for the latest requirements.

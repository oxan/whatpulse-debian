WhatPulse requires some packages and permissions to work properly.

Please read http://whatpulse.org/kb/content/7/15/en/linux-installation.html for the latest requirements.

By installing WhatPulse you agree to the Privacy Policy (http://whatpulse.org/privacy) and Terms of Service (http://whatpulse.org/tos).

Furthermore, WhatPulse is provided to users on an "as it is" basis, without warranty of any kind, whether expressed or implied. This includes any kind of warranty or guarentee that WhatPulse is free of defects, and any kind of warranty or guarantee that WhatPulse will not do any damage to your computer. There is no person or entity that can hold the author of WhatPulse liable for any damages caused by use of WhatPulse, or through any other means. You, the user, by continuing with the installation and use of WhatPulse, assume all risk of its use and of the consequences of its use. If you do not agree to these terms, you are not permitted to continue to use WhatPulse in any way.

